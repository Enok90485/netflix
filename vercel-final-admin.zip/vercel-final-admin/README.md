
# Netflix Admin + 3 Devices - Vercel Deploy Final

Versión: Admin solo ve panel admin, usuarios ven streaming.
Control 3 dispositivos simultáneos con token.

Usuarios:
- admin / admin123 (rol admin) -> solo panel admin
- demo / demo123 (rol user) -> streaming
- luis / luis123 (rol user)

Features:
- Fix Forbidden 8%20mile (valida ID numérico 1228834)
- TMDB key 8bf28bc799a2f8deef5dcb77e3f4d689
- Espejos vidsrc.sh/to/me/net/in/pm/xyz/icu
- PLAYER_EVENT

Deploy:
1. Vercel -> New Project -> Import o drag zip
2. Framework: Other, Build: empty, Output: .
3. Deploy

Para actualizar existente: ver README_UPDATE.md
