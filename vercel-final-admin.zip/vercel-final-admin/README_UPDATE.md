
# Cómo actualizar el que YA tienes desplegado en Vercel

Tienes 3 opciones, de más fácil a más pro:

## OPCIÓN A - Si lo desplegaste con GitHub (recomendado)
Si tu proyecto actual está conectado a GitHub:

1. En tu PC, abre la carpeta del repo:
   git pull

2. Reemplaza el index.html con el nuevo (este zip):
   cp ~/Downloads/vercel-final-admin/index.html ./index.html

3. Push:
   git add .
   git commit -m "feat: admin solo admin + 3 dispositivos"
   git push origin main

Vercel detecta el push y redeploya SOLO en ~40 seg. Tu dominio se mantiene.

## OPCIÓN B - Si lo desplegaste subiendo ZIP / drag & drop (sin Git)
1. Ve a vercel.com -> tu proyecto -> Settings -> Git -> Si no tiene git, ve a Deployments tab
2. Arrastra el nuevo ZIP (vercel-final-admin.zip) en el dashboard de Vercel:
   - O en la pestaña Deployments -> 3 puntitos del último deployment -> Redeploy -> pero sube nuevo
   - Mejor: Vercel Dashboard -> Add New -> Project -> vuelve a importar el ZIP, Vercel te preguntará si quieres reemplazar o crear nuevo, elige mismo proyecto

O usa CLI:
npm i -g vercel
cd vercel-final-admin
vercel --prod --prebuilt
-> selecciona Link to existing project -> elige tu proyecto actual
-> redeploya sobre el mismo dominio

## OPCIÓN C - Deploy Hook (actualización con 1 comando)
Si creaste un Deploy Hook en Vercel:

En tu proyecto Vercel: Settings -> Git -> Deploy Hooks -> Create Hook -> copia URL

Luego cada vez que quieras actualizar el sitio ya desplegado sin entrar a Vercel:

curl -X POST https://api.vercel.com/v1/integrations/deploy/prj_xxx/xxx

Eso fuerza rebuild con el último commit. Si usaste Opción A, ya lo hace automático.

## Qué pasa con tu dominio?
- Si usas *.vercel.app: se mantiene mismo dominio, solo cambia código
- Si usas dominio custom: también se mantiene, no tienes que reconfigurar DNS
- No pierdes variables de entorno

## Test después de actualizar
1. Entra como admin / admin123 -> debe verse SOLO panel admin (sidebar oscuro, sin hero películas)
2. Entra como demo / demo123 -> debe verse plataforma streaming normal
3. Abre 3 pestañas incógnito con demo -> 4ta debe pedir cerrar dispositivo
4. Busca "8 mile" -> ID 1228834 -> no debe dar Forbidden
