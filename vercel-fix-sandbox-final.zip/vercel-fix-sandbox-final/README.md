FIX: This content can't be embedded in a sandboxed frame

- Se eliminó atributo sandbox del iframe player
- Ahora: <iframe allow="autoplay; fullscreen; encrypted-media" allowfullscreen>
- En vercel.app real funciona integrado, sin necesidad de abrir en pestaña nueva
- Si ves el error solo en preview del editor de Vercel, es normal (preview está en sandbox), en dominio real no sale.

Usuarios:
admin / admin123 -> solo admin panel
demo / demo123 -> streaming
luis / luis123 -> streaming
